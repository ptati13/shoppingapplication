package srh.de.shoppingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
